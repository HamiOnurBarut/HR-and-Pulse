clear all;
close all;
a = arduino('com3', 'uno');      
data = zeros(100,1);
t = cputime;
m = 1;
n = 2;
for i = 1:100

       time(i) = cputime-t;
    data(i,1) = readVoltage(a, 'A0')*(10000);

    if i > 1
        if data(i-1,1) < 45000 && data(i,1)> 45000 %IF QS=true
            data1(n) = time(i);
            bpm(m) = 60/(data1(n)-data1(n-1));
            m = m+1;
            n = n+1;
        end
    end

end
% time = cputime - t;
% [a b] = size(data);
% t = linspace(0, time, a);
% plot(data,t);
bpm(1)=0;
figure(1);
plot(time,data);title('Plot of Sensor Data');
figure(3);
plot(bpm);title('BPM over time');
bpm_sum=0;
for i=1:length(bpm)
    bpm_sum=bpm(i)+bpm_sum;
end
AverageOfBPM=bpm_sum/length(bpm)