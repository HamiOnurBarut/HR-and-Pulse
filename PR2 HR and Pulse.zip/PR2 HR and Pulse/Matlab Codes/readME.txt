realdeal.m gets the data and plots it
ardget.m does the same thing but it also plots the heart rate of recorded person.