clear all;
close all;
a = arduino('com3' , 'uno' );
data = zeros(500,1);
t = cputime;
for i = 1:500
time(i) = cputime-t;
data(i,1) = readVoltage(a, 'A0' )*(1024/5);
end
plot(time, data);